// This file is shared across every page (loaded at the bottom of each .html file)

const btn = document.getElementById('clickBtn');
const msg = document.getElementById('clickMsg');

// Only run this on pages that actually have the button (like index.html)
if (btn) {
  btn.addEventListener('click', () => {
    msg.textContent = 'Button clicked! Edit this behavior in script.js.';
  });
}
